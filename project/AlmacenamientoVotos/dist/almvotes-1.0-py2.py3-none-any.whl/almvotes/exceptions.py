class PollDateException(Exception):
    pass

class NoQuestionOptionException(Exception):
    pass

class NoUserException(Exception):
    pass

class MoreThanOneVoteException(Exception):
    pass
